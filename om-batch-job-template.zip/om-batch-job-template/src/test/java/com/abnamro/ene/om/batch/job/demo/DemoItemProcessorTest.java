package com.abnamro.ene.om.batch.job.demo;

import com.abnamro.ene.generic.domain.models.OMBatchRecord;
import com.abnamro.ene.generic.domain.models.OMParty;
import com.abnamro.ene.generic.domain.models.PersonalDetails;
import com.abnamro.ene.generic.domain.models.SchemeBasedId;
import org.junit.jupiter.api.Test;
import org.springframework.batch.item.ItemProcessor;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class DemoItemProcessorTest {
    private final ItemProcessor<OMBatchRecord, OMBatchRecord> demoItemProcessor = new DemoItemProcessor();

    @Test
    void testProcessorShouldSetBirthdayMessage_WhenBirthdayIsToday() throws Exception {
        OMBatchRecord batchRecord = createDummyBatchRecord(LocalDate.now());
        String expectedMessage = "Happy Birthday,";
        OMBatchRecord processedRecord = demoItemProcessor.process(batchRecord);
        assertNotNull(processedRecord);
        assertTrue(processedRecord.getOwner().getSalutation().getId().contains(expectedMessage));
    }

    @Test
    void testProcessorShouldNotContainBirthdayMessage_WhenBirthdayIsNotToday() throws Exception {
        OMBatchRecord batchRecord = createDummyBatchRecord(LocalDate.of(2000, 12, 7));
        String expectedMessage = "Happy Birthday,";
        OMBatchRecord processedRecord = demoItemProcessor.process(batchRecord);
        assertNotNull(processedRecord);
        assertFalse(processedRecord.getOwner().getSalutation().getId().contains(expectedMessage));
    }

    private OMBatchRecord createDummyBatchRecord(LocalDate date) {
        OMBatchRecord batchRecord = new OMBatchRecord();
        PersonalDetails personalDetails = new PersonalDetails();
        OMParty owner = new OMParty();
        setPersonalDetails(date, personalDetails, owner, batchRecord);
        return batchRecord;
    }

    private void setPersonalDetails(LocalDate date, PersonalDetails personalDetails, OMParty owner, OMBatchRecord batchRecord) {
        personalDetails.setDateOfBirth(date);
        owner.setPersonalDetails(personalDetails);
        owner.setSalutation(createDummySalutation());
        batchRecord.setOwner(owner);
    }

    private SchemeBasedId createDummySalutation() {
        SchemeBasedId scheme = new SchemeBasedId();
        scheme.setScheme("Salutation test");
        scheme.setId("Mr.");
        return scheme;
    }
}