package com.abnamro.ene.om.batch.job.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles({"demo"})
class ApplicationTests {
	@Test
	void contextLoads() {
		// no-op
	}
}
