package com.abnamro.ene.om.batch.job.demo;

import com.abnamro.ene.generic.utils.writers.OMBatchWriter;
import com.abnamro.ene.om.batch.job.core.config.BatchConfig;
import org.junit.jupiter.api.*;
import org.springframework.batch.core.*;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.batch.test.JobRepositoryTestUtils;
import org.springframework.batch.test.context.SpringBatchTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.*;

@SpringBatchTest
@SpringJUnitConfig({BatchConfig.class, DemoJobConfig.class})
@PropertySource("classpath:application.properties")
@EnableAutoConfiguration
@DirtiesContext
@ActiveProfiles(value = "demo")
class SpringBootBatchDemoIntegrationTest {
    private static final String JOB_NAME = "demoJob";
    @Autowired
    private JobLauncherTestUtils jobLauncherTestUtils;
    @Autowired
    private JobRepositoryTestUtils jobRepositoryTestUtils;
    @Value("${file.input}")
    private String input;
    @Value("${file.inputTemplate}")
    private String inputTemplate;

    @BeforeEach
    void setupInputFile() throws IOException {
        var inputFile = new File(input);
        if (!inputFile.exists()) {
            assert inputFile.createNewFile();
            try (var writer = Files.newBufferedWriter(Path.of(input))) {
                List<String> lines = Files.readAllLines(Path.of(inputTemplate));
                lines.forEach(line -> {
                    line = line.replaceAll("REPLACE_WITH_DATE", LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
                    try {
                        writer.write(line);
                        writer.newLine();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
            inputFile.deleteOnExit();
        }
    }

    @AfterEach
    public void cleanUp() {
        jobRepositoryTestUtils.removeJobExecutions();
    }

    @Test
    void testJobExecutionSuccess() throws Exception {
        var inputResource = new FileSystemResource(input);
        assumeTrue(inputResource.exists());

        JobExecution jobExecution = jobLauncherTestUtils.launchJob();

        JobInstance jobInstance = jobExecution.getJobInstance();
        assertNotNull(jobInstance);
        assertEquals(JOB_NAME, jobInstance.getJobName());
        ExitStatus jobExitStatus = jobExecution.getExitStatus();
        assertNotNull(jobExitStatus);
        assertEquals("COMPLETED", jobExitStatus.getExitCode(), jobExitStatus.getExitDescription());
    }

    @Test
    void testOutputFileValidity_whenJobExecuted() throws Exception {
        var inputResource = new FileSystemResource(input);
        assumeTrue(inputResource.exists());

        var jobExecution = jobLauncherTestUtils.launchJob();

        var stepExecution = jobExecution.getStepExecutions().iterator().next();
        var stepContext = stepExecution.getExecutionContext();
        var pathString = stepContext.getString(OMBatchWriter.OUTPUT_FILE_PATH);
        assertNotNull(pathString);
        var outputPath = Path.of(pathString);
        assertTrue(outputPath.toFile().exists());
        List<String> actualLines = Files.readAllLines(outputPath);
        List<String> expectedLines = Files.readAllLines(inputResource.getFile().toPath());
        var expectedCount = expectedLines.size() + (expectedLines.get(expectedLines.size() - 1).startsWith("EOD") ? 0 : 1);
        assertEquals(expectedCount, actualLines.size());
    }

    @Test
    void testProcessorAddsBirthdayMessage_WhenCustomerBirthdayIsToday() throws Exception {
        var inputResource = new FileSystemResource(input);
        assumeTrue(inputResource.exists());

        JobExecution jobExecution = jobLauncherTestUtils.launchJob();

        assertEquals(ExitStatus.COMPLETED, jobExecution.getExitStatus());
        var stepExecution = jobExecution.getStepExecutions().iterator().next();
        var stepContext = stepExecution.getExecutionContext();
        var pathString = stepContext.getString(OMBatchWriter.OUTPUT_FILE_PATH);
        assertNotNull(pathString);
        var outputPath = Path.of(pathString);
        assertTrue(outputPath.toFile().exists());
        List<String> lines = Files.readAllLines(outputPath);
        boolean hasBirthdayMessage = lines.stream().anyMatch(line -> line.contains("Happy Birthday"));
        assertTrue(hasBirthdayMessage, "The output file should contain a birthday message!");
    }
}
