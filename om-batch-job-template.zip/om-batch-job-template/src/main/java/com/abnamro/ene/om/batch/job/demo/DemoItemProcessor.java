package com.abnamro.ene.om.batch.job.demo;


import com.abnamro.ene.generic.domain.models.OMBatchRecord;
import lombok.extern.log4j.Log4j2;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Log4j2
@Component
public class DemoItemProcessor implements ItemProcessor<OMBatchRecord, OMBatchRecord> {

    @Override
    public OMBatchRecord process(OMBatchRecord batchRecord) {
        LocalDate dateOfBirth = batchRecord.getOwner().getPersonalDetails().getDateOfBirth();
        LocalDate today = LocalDate.now();
        if (dateOfBirth != null &&
                dateOfBirth.getMonth() == today.getMonth() &&
                dateOfBirth.getDayOfMonth() == today.getDayOfMonth()) {
            String salutation = String.valueOf(batchRecord.getOwner().getSalutation().getId());
            String congratulations = ("Happy Birthday, ").concat(salutation).concat("!");
            batchRecord.getOwner().getSalutation().setId(congratulations);
        }
        return batchRecord;
    }
}
