package com.abnamro.ene.om.batch.job.demo;

import com.abnamro.ene.generic.utils.writers.OMBatchWriter;
import lombok.extern.log4j.Log4j2;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

@Log4j2
@Component
public class JobCompletionNotificationListener implements JobExecutionListener {
    @Override
    public void afterJob(JobExecution jobExecution) {
        if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
            var stepExecution = jobExecution.getStepExecutions().iterator().next();
            var outputPath = stepExecution.getExecutionContext().getString(OMBatchWriter.OUTPUT_FILE_PATH);
            log.info("!!! JOB FINISHED! Time to verify the results, output file located at: {}", outputPath);
        }
    }
}