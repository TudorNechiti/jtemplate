package com.abnamro.ene.om.batch.job.core.config;

import com.abnamro.ene.generic.domain.enums.BatchField;
import com.abnamro.ene.generic.domain.interfaces.BuildableDTO;
import com.abnamro.ene.generic.domain.models.dto.*;
import com.abnamro.ene.generic.domain.models.dto.formatters.*;
import com.abnamro.ene.generic.domain.models.dto.formatters.factories.DTOFormatterFactory;
import com.abnamro.ene.generic.domain.models.dto.mappers.BatchToFooterDTOMapper;
import com.abnamro.ene.generic.domain.models.dto.mappers.BatchToHeaderDTOMapper;
import com.abnamro.ene.generic.domain.models.dto.mappers.DynamicFieldSetMapper;
import com.abnamro.ene.generic.domain.models.mappers.*;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PassThroughFieldSetMapper;
import org.springframework.batch.item.file.mapping.PassThroughLineMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.LineAggregator;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.file.transform.PassThroughLineAggregator;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import java.time.format.DateTimeFormatter;
import java.util.Map;

@Configuration
public class BatchConfig {
    private static final String PIPE_DELIMITER = "|";

    @Bean("dateTimeFormatter")
    public DateTimeFormatter dateTimeFormatter() {
        return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    }

    @Bean("dateFormatter")
    public DateTimeFormatter dateFormatter() {
        return DateTimeFormatter.ofPattern("dd-MM-yyyy");
    }

    @Bean("pureNumericDateFormatter")
    public DateTimeFormatter pureNumericDateFormatter() {
        return DateTimeFormatter.ofPattern("yyyyMMdd");
    }

    @Bean("taskExecutor")
    public TaskExecutor taskExecutor() {
        return new SimpleAsyncTaskExecutor();
    }

    /**
     * MAPPERS section
     */
    @Bean("lineAggregator")
    public LineAggregator<String> lineAggregator() {
        return new PassThroughLineAggregator<>();
    }

    @Bean("defaultFieldSetMapper")
    public PassThroughFieldSetMapper defaultFieldSetMapper() {
        return new PassThroughFieldSetMapper();
    }

    @Bean("passThroughLineMapper")
    public LineMapper<String> passThroughLineMapper() {
        return new PassThroughLineMapper();
    }

    @Bean("pipeFieldTokenizer")
    public LineTokenizer pipeFieldTokenizer() {
        var tokenizer = new DelimitedLineTokenizer();
        tokenizer.setDelimiter("|");
        tokenizer.setStrict(false);

        return tokenizer;
    }

    /**
     * DTO to internal mappers
     */
    @Bean
    public ArchivalDetailsMapper archivalDetailsMapper() {
        return new ArchivalDetailsMapper(dateFormatter());
    }

    @Bean
    public BASEArchiveDetailsMapper baseArchiveDetailsMapper() {
        return new BASEArchiveDetailsMapper();
    }

    @Bean
    public BankMailOverrideDetailsMapper bankMailOverrideDetailsMapper() {
        return new BankMailOverrideDetailsMapper(dateFormatter());
    }

    @Bean
    public EArchiveDetailsMapper eArchiveDetailsMapper() {
        return new EArchiveDetailsMapper(pureNumericDateFormatter());
    }

    @Bean
    public OCMCompositeKeyMapper ocmCompositeKeyMapper() {
        return new OCMCompositeKeyMapper();
    }

    @Bean
    public OMBankMailDetailsMapper omBankMailDetailsMapper() {
        return new OMBankMailDetailsMapper();
    }

    @Bean
    public OMBatchMapper omBatchMapper() {
        return new OMBatchMapper();
    }

    @Bean
    public OMBatchRecordMapper omBatchRecordMapper() {
        return new OMBatchRecordMapper(omPartyMapper(),
                schemeBasedIdMapper(),
                baseArchiveDetailsMapper(),
                ocmCompositeKeyMapper(),
                eArchiveDetailsMapper(),
                omChannelMapper(),
                bankMailOverrideDetailsMapper(),
                archivalDetailsMapper(),
                relatedEntityMapper(),
                omBatchScopeMapper());
    }

    @Bean
    public OMBatchScopeMapper omBatchScopeMapper() {
        return new OMBatchScopeMapper();
    }

    @Bean
    public OMChannelMapper omChannelMapper() {
        return new OMChannelMapper(schemeBasedIdMapper());
    }

    @Bean
    public OMEmailDetailsMapper omEmailDetailsMapper() {
        return new OMEmailDetailsMapper();
    }

    @Bean
    public OMMobileAppDetailsMapper omMobileAppDetailsMapper() {
        return new OMMobileAppDetailsMapper();
    }

    @Bean
    public OMPartyMapper omPartyMapper() {
        return new OMPartyMapper(schemeBasedIdMapper(),
                personalDetailsMapper(),
                addressMapper(),
                phoneNumberMapper(),
                omWebResourceMapper(),
                omEmailDetailsMapper(),
                omMobileAppDetailsMapper(),
                omBankMailDetailsMapper());
    }

    @Bean
    public OMWebResourceMapper omWebResourceMapper() {
        return new OMWebResourceMapper();
    }

    @Bean
    public PersonalDetailsMapper personalDetailsMapper() {
        return new PersonalDetailsMapper(dateFormatter());
    }

    @Bean
    public PhoneNumberMapper phoneNumberMapper() {
        return new PhoneNumberMapper();
    }

    @Bean
    public RelatedEntityMapper relatedEntityMapper() {
        return new RelatedEntityMapper();
    }

    @Bean
    public SchemeBasedIdMapper schemeBasedIdMapper() {
        return new SchemeBasedIdMapper();
    }

    @Bean
    public AddressMapper addressMapper() {
        return new AddressMapper();
    }

    @Bean
    public BatchToHeaderDTOMapper batchToHeaderDTOMapper() {
        return new BatchToHeaderDTOMapper();
    }

    @Bean
    public BatchToFooterDTOMapper batchToFooterDTOMapper() {
        return new BatchToFooterDTOMapper();
    }


    /**
     * FieldSet to DTO mappers
     */
    @Bean("headerFieldSetMapper")
    public FieldSetMapper<BuildableDTO> headerFieldSetMapper() {
        return new DynamicFieldSetMapper<>(HeaderDTO.class, BatchField.SECTION.HEADER);
    }

    @Bean("genericFieldSetMapper")
    public FieldSetMapper<BuildableDTO> genericFieldSetMapper() {
        return new DynamicFieldSetMapper<>(GenericDTO.class, BatchField.SECTION.GENERIC);
    }

    @Bean("archivalFieldSetMapper")
    public FieldSetMapper<BuildableDTO> archivalFieldSetMapper() {
        return new DynamicFieldSetMapper<>(ArchivalDTO.class, BatchField.SECTION.ARCHIVAL);
    }

    @Bean("scopeFieldSetMapper")
    public FieldSetMapper<BuildableDTO> scopeFieldSetMapper() {
        return new DynamicFieldSetMapper<>(ScopeDTO.class, BatchField.SECTION.SCOPE);
    }

    @Bean("relatedEntityFieldSetMapper")
    public FieldSetMapper<BuildableDTO> relatedEntityFieldSetMapper() {
        return new DynamicFieldSetMapper<>(RelatedEntityDTO.class, BatchField.SECTION.RELATED_ENTITY);
    }

    @Bean("payloadFieldSetMapper")
    public FieldSetMapper<BuildableDTO> payloadFieldSetMapper() {
        return new DynamicFieldSetMapper<>(PayloadDTO.class, BatchField.SECTION.PAYLOAD);
    }

    @Bean("additionalAttributeFieldSetMapper")
    public FieldSetMapper<BuildableDTO> additionalAttributeFieldSetMapper() {
        return new DynamicFieldSetMapper<>(AdditionalAttributeDTO.class, BatchField.SECTION.ADDITIONAL_ATTRIBUTES);
    }

    @Bean("footerFieldSetMapper")
    public FieldSetMapper<BuildableDTO> footerFieldSetMapper() {
        return new DynamicFieldSetMapper<>(FooterDTO.class, BatchField.SECTION.FOOTER);
    }

    /**
     * DTO Formatters ---> These add a delimiter between each value within a record
     */

    @Bean
    public ArchivalDTOFormatter archivalDTOFormatter() {
        return new ArchivalDTOFormatter(new DelimitedValuesFormatterImpl(PIPE_DELIMITER));
    }

    @Bean
    public GenericDTOFormatter genericDTOFormatter() {
        return new GenericDTOFormatter(new DelimitedValuesFormatterImpl(PIPE_DELIMITER));
    }

    @Bean
    public AdditionalAttributeDTOFormatter additionalAttributeDTOFormatter() {
        return new AdditionalAttributeDTOFormatter(new DelimitedValuesFormatterImpl(PIPE_DELIMITER));
    }

    @Bean
    public HeaderDTOFormatter headerDTOFormatter() {
        return new HeaderDTOFormatter(new DelimitedValuesFormatterImpl(PIPE_DELIMITER));
    }

    @Bean
    public PayloadDTOFormatter payloadDTOFormatter() {
        return new PayloadDTOFormatter(new DelimitedValuesFormatterImpl(PIPE_DELIMITER));
    }

    @Bean
    public RelatedEntityDTOFormatter relatedEntityDTOFormatter() {
        return new RelatedEntityDTOFormatter(new DelimitedValuesFormatterImpl(PIPE_DELIMITER));
    }

    @Bean
    public ScopeDTOFormatter scopeDTOFormatter() {
        return new ScopeDTOFormatter(new DelimitedValuesFormatterImpl(PIPE_DELIMITER));
    }

    @Bean
    public FooterDTOFormatter footerDTOFormatter() {
        return new FooterDTOFormatter(new DelimitedValuesFormatterImpl(PIPE_DELIMITER));
    }

    @Bean
    public DTOFormatterFactory dtoFormatterFactory() {
        return new DTOFormatterFactory(
                additionalAttributeDTOFormatter(),
                archivalDTOFormatter(),
                footerDTOFormatter(),
                genericDTOFormatter(),
                headerDTOFormatter(),
                payloadDTOFormatter(),
                relatedEntityDTOFormatter(),
                scopeDTOFormatter());
    }

    /**
     * Line mapper responsible for transforming a line of text from a file into a DTO
     * i) Splits a line into fields using a pipe-delimiter. Then, it maps the fields from the
     * tokenizer to a DTO.
     * ii) Each type of line(e.g. HEADER, ARCHIVAL, PAYLOAD etc.) has its own FieldSetMapper.
     */
    @Bean("lineMapper")
    public LineMapper<BuildableDTO> lineMapper(
            LineTokenizer pipeFieldTokenizer,
            @Qualifier("headerFieldSetMapper") FieldSetMapper<BuildableDTO> headerFieldSetMapper,
            @Qualifier("genericFieldSetMapper") FieldSetMapper<BuildableDTO> genericFieldSetMapper,
            @Qualifier("archivalFieldSetMapper") FieldSetMapper<BuildableDTO> archivalFieldSetMapper,
            @Qualifier("additionalAttributeFieldSetMapper") FieldSetMapper<BuildableDTO> additionalAttributeFieldSetMapper,
            @Qualifier("relatedEntityFieldSetMapper") FieldSetMapper<BuildableDTO> relatedEntityFieldSetMapper,
            @Qualifier("scopeFieldSetMapper") FieldSetMapper<BuildableDTO> scopeFieldSetMapper,
            @Qualifier("payloadFieldSetMapper") FieldSetMapper<BuildableDTO> payloadFieldSetMapper,
            @Qualifier("footerFieldSetMapper") FieldSetMapper<BuildableDTO> footerFieldSetMapper
    ) {
        var lineMapper = new PatternMatchingCompositeLineMapper<BuildableDTO>();
        lineMapper.setTokenizers(Map.of("*", pipeFieldTokenizer));
        lineMapper.setFieldSetMappers(Map.of(
                "000|*", headerFieldSetMapper,
                "*|ARCHIVALDETAILS*", archivalFieldSetMapper,
                "*|ADDITIONALATTRIBUTES*", additionalAttributeFieldSetMapper,
                "*|RELATEDENTITY*", relatedEntityFieldSetMapper,
                "*|SCOPE*", scopeFieldSetMapper,
                "*|PAYLOAD*", payloadFieldSetMapper,
                "EOD*", footerFieldSetMapper,
                "*", genericFieldSetMapper
        ));
        return lineMapper;
    }
}
