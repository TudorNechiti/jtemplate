package com.abnamro.ene.om.batch.job.core.service;

import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@ComponentScan({"com.abnamro.ene.om.batch.job"})
public class JobService {
    private final JobLauncher jobLauncher;
    private final Job job;

    public void run(JobParameters jobParameters) throws JobExecutionException {
        jobLauncher.run(job, jobParameters);
    }
}
