package com.abnamro.ene.om.batch.job.impl;

import jdk.jshell.spi.ExecutionControl;
import org.springframework.batch.core.Job;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("implemented") //todo: double check if we want to call the profile this.
public class JobConfig {
    @Bean
    public Job job() throws ExecutionControl.NotImplementedException {
        throw new ExecutionControl.NotImplementedException("Not yet implemented");
    }
}
