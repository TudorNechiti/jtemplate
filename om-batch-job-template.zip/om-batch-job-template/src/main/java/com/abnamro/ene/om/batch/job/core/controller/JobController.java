package com.abnamro.ene.om.batch.job.core.controller;

import com.abnamro.ene.om.batch.job.core.service.JobService;
import lombok.RequiredArgsConstructor;
import lombok.extern.java.Log;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static java.util.logging.Level.*;


@RestController
@RequestMapping("/jobs")
@RequiredArgsConstructor
@ComponentScan({"com.abnamro.ene.om.batch.job"})
@Log
public class JobController {
    private final JobService jobService;

    @PostMapping("/startJob")
    public ResponseEntity<String> startJob() {
        var params = new JobParameters();
        try {
            jobService.run(params);
            return ResponseEntity.ok("Job started");
        } catch (JobExecutionException e) {
            log.log(WARNING, "Failed to start job", e);
            return ResponseEntity.internalServerError().body("Job failed to start");
        }
    }
}
