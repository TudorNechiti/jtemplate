package com.abnamro.ene.om.batch.job.demo;

import com.abnamro.ene.generic.domain.interfaces.BuildableDTO;
import com.abnamro.ene.generic.domain.models.OMBatchRecord;
import com.abnamro.ene.generic.domain.models.dto.formatters.factories.DTOFormatterFactory;
import com.abnamro.ene.generic.domain.models.dto.mappers.BatchToFooterDTOMapper;
import com.abnamro.ene.generic.domain.models.dto.mappers.BatchToHeaderDTOMapper;
import com.abnamro.ene.generic.domain.models.mappers.OMBatchMapper;
import com.abnamro.ene.generic.domain.models.mappers.OMBatchRecordMapper;
import com.abnamro.ene.generic.utils.readers.OMBatchReader;
import com.abnamro.ene.generic.utils.services.BlobService;
import com.abnamro.ene.generic.utils.services.StubBlobService;
import com.abnamro.ene.generic.utils.writers.OMBatchWriter;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.transform.LineAggregator;
import org.springframework.batch.item.support.AbstractFileItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.FileSystemResource;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@ComponentScan(basePackages = {"com.abnamro.ene.om.batch.job.core", "com.abnamro.ene.om.batch.job.demo"})
@Profile("demo")
public class DemoJobConfig {
    @Value("${file.input}")
    private String fileInput;

    private final OMBatchRecordMapper omBatchRecordMapper;
    private final OMBatchMapper omBatchMapper;
    private final BatchToHeaderDTOMapper batchToHeaderDTOMapper;
    private final BatchToFooterDTOMapper batchToFooterDTOMapper;
    private final DTOFormatterFactory dtoFormatterFactory;
    private final JobCompletionNotificationListener listener;
    private final LineMapper<BuildableDTO> lineMapper;
    private final LineAggregator<String> lineAggregator;

    public DemoJobConfig(OMBatchRecordMapper omBatchRecordMapper,
                         OMBatchMapper omBatchMapper,
                         BatchToHeaderDTOMapper batchToHeaderDTOMapper,
                         BatchToFooterDTOMapper batchToFooterDTOMapper,
                         DTOFormatterFactory dtoFormatterFactory,
                         JobCompletionNotificationListener listener,
                         LineMapper<BuildableDTO> lineMapper,
                         LineAggregator<String> lineAggregator) {
        this.omBatchRecordMapper = omBatchRecordMapper;
        this.omBatchMapper = omBatchMapper;
        this.batchToHeaderDTOMapper = batchToHeaderDTOMapper;
        this.batchToFooterDTOMapper = batchToFooterDTOMapper;
        this.dtoFormatterFactory = dtoFormatterFactory;
        this.listener = listener;
        this.lineMapper = lineMapper;
        this.lineAggregator = lineAggregator;
    }

    @Bean
    public Job demoJob(JobRepository jobRepository, Step step1) {
        return new JobBuilder("demoJob", jobRepository)
                .incrementer(new RunIdIncrementer())
                .listener(listener)
                .flow(step1)
                .end()
                .build();
    }

    @Bean
    public Step step1(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("step1", jobRepository)
                .<OMBatchRecord, OMBatchRecord>chunk(10, transactionManager)
                .reader(customReader())
                .processor(demoItemProcessor())
                .writer(omBatchWriter())
                .build();
    }

    @Bean
    @StepScope
    public OMBatchReader customReader() {
        return new OMBatchReader(
                omBatchMapper,
                omBatchRecordMapper,
                delegateReader());
    }

    @Bean
    @StepScope
    public FlatFileItemReader<BuildableDTO> delegateReader() {
        return new FlatFileItemReaderBuilder<BuildableDTO>()
                .name("delegateReader")
                .lineMapper(lineMapper)
                .resource(new FileSystemResource(fileInput))
                .build();
    }

    @Bean
    @StepScope
    public OMBatchWriter omBatchWriter() {
        return new OMBatchWriter(
                blobService(),
                delegateWriter(),
                batchToHeaderDTOMapper,
                batchToFooterDTOMapper,
                omBatchRecordMapper,
                dtoFormatterFactory);
    }

    @Bean
    public BlobService<FileSystemResource> blobService() {
        return new StubBlobService<>(null, null);
    }

    @Bean
    @StepScope
    public AbstractFileItemWriter<String> delegateWriter() {
        return new FlatFileItemWriterBuilder<String>()
                .name("delegateWriter")
                .lineAggregator(lineAggregator)
                .build();

    }

    @Bean
    @StepScope
    public DemoItemProcessor demoItemProcessor() {
        return new DemoItemProcessor();
    }
}
